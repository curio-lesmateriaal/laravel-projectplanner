


<?php $__env->startSection('title'); ?>
    Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Projects</h1>
    <ul class="list-group">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <li class="list-group-item">
                <?php echo e($project->title); ?> 
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectplanner\resources\views/projects/index.blade.php ENDPATH**/ ?>