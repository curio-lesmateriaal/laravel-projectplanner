@extends('layouts.main')

@section('title')
 Homepage
@endsection

@section('content')
<h1>Homepage</h1>
<div class="row">
    <div class="col">
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iure dolore, labore harum natus quibusdam laboriosam consectetur quis suscipit nostrum quaerat maiores neque explicabo ipsam nobis qui aperiam hic ex! Reprehenderit?</p>
    </div>
    <div class="col">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aperiam itaque consequuntur non sed voluptates? Similique quia officiis inventore at molestiae, voluptatum cum quas tempore? Aspernatur sunt aperiam adipisci expedita inventore!</p>
    </div>
    <div class="col">
        <img width="100%" src="http://placehold.it/200x200" alt="">

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus tenetur, in quos iste obcaecati recusandae distinctio reiciendis, fuga ut laudantium neque eveniet rerum qui. Hic nemo tempore commodi soluta. Placeat!</p>
    </div>
</div>
  @endsection

