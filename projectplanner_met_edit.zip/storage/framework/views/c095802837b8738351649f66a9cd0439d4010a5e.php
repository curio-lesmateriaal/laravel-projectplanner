

<?php $__env->startSection('title'); ?>
   Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo e($project); ?>

    <h1>Detail page: <?php echo e($project->title); ?></h1>
    <p><?php echo e($project->description); ?> </p>

    <p>startdate: <?php echo e($project->startdate); ?></p>
    <p>status: <?php echo e($project->status); ?></p>

    <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-info">Edit project</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectplanner\resources\views/projects/show.blade.php ENDPATH**/ ?>