

<?php $__env->startSection('title'); ?>
   Edit project
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo e($project); ?>

    <h1>Edit project</h1>
    <form action="" method="POST">
        
        <div class="form-group">
            <label for="">Titel</label>
            <input value="<?php echo e($project->title); ?>" type="text" name="title" class="form-control">
        </div>

        <div class="form-group">
            <label for="">Startdatum</label>
            <input value="<?php echo e($project->startdate); ?>" type="text" name="startdate" class="form-control">
        </div>

        <div class="form-group">
            <label for="">Einddatum</label>
            <input value="<?php echo e($project->enddate); ?>" type="text" name="enddate" class="form-control">
        </div>

        <div class="form-group">
            <label for="">Omschrijving</label>
            <textarea name="description" class="form-control"><?php echo e($project->description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="">Status</label>
            <select name="status" class="form-control">
                <option value="bezig" <?php if($project->status == 'bezig'): ?> selected <?php endif; ?>> bezig </option>
                <option value="open" <?php if($project->status == 'open'): ?> selected <?php endif; ?>> open </option>
                <option value="afgerond" <?php if($project->status == 'afgerond'): ?> selected <?php endif; ?>> afgerond </option>
            </select>
        </div>

        <input type="submit" value="Wijzig project" class="btn btn-primary">

    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectplanner\resources\views/projects/edit.blade.php ENDPATH**/ ?>