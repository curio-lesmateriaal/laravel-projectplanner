@extends('layouts.main')

@section('title')
   Details
@endsection

@section('content')
    <h1>Detail page: {{ $project->title }}</h1>
    <p>{{ $project->description }} </p>

    <p><b>Project Owner:</b> {{ $project->owner->username }} </p>
    <p>Other projects by this owner:</p>
    <ul>
        @foreach($project->owner->projects as $project)
            <li>{{$project->title }}</li>
        @endforeach
    </ul>


    <h3>tasks!</h3>
    <ul class="list-group">
        @foreach($project->tasks as $task)
            <li class="list-group-item"> {{ $task->title }} </li>
        @endforeach
    </ul>

@endsection