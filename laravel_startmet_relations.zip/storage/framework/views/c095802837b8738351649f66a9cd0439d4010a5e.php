

<?php $__env->startSection('title'); ?>
   Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Detail page: <?php echo e($project->title); ?></h1>
    <p><?php echo e($project->description); ?> </p>

    <p><b>Project Owner:</b> <?php echo e($project->owner->username); ?> </p>
    <p>Other projects by this owner:</p>
    <ul>
        <?php $__currentLoopData = $project->owner->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($project->title); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


    <h3>tasks!</h3>
    <ul class="list-group">
        <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"> <?php echo e($task->title); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectplanner\resources\views/projects/show.blade.php ENDPATH**/ ?>